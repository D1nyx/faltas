<?php
    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '123456';
    $dbName = 'marcacao-ferias';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

?>